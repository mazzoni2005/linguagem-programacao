public class TesteMain {
    public static void main(String[] args) {
        PetShop petShop = new PetShop("Pet Shop Mazzoni");

        Pet pet1 = new Pet("Milly", "Shih-Tzu");
        Pet pet2 = new Pet("Hannah", "Shih-Tzu");
        Pet pet3 = new Pet("Mike", "Shih-Tzu");

        petShop.darBanho(pet1, 50.0);
        petShop.darBanho(pet2, 50.0, 10);
        petShop.darBanho(pet3, 35.0);

        System.out.println("Faturamento Total do Pet Shop: " + petShop.getFaturamentoTotal());
        System.out.println(pet1);
        System.out.println(pet2);
        System.out.println(pet3);
    }
}

