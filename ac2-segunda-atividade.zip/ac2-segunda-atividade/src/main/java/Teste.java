public class Teste {
    public static void main(String[] args) {
        Atividade atividade01 = new Atividade("Andar até a Aparecida do Norte", "Robson Ramos", 14);
        atividade01.terminarAtividade(7);
        atividade01.exibirRelatorio();
        Atividade atividade02 = new Atividade("Terminar um quebra-cabeça", "Enzo Stane", 2);
        atividade02.terminarAtividade(2);
        atividade02.exibirRelatorio();
        Atividade atividade03 = new Atividade("Terminar de tirar a carta", "Lucas Gianine", 3);
        atividade03.terminarAtividade(4);
        atividade03.exibirRelatorio();


        System.out.println(atividade01.toString());
        System.out.println(atividade02.toString());
        System.out.println(atividade03.toString());
    }
}
