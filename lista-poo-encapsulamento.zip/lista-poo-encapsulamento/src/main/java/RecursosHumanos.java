public class RecursosHumanos {
    private int totalPromovidos;
    private int totalSalariosReajustados;

    public void reajustarSalario(Colaborador colaborador, double valorReajuste) {
        double novoSalario = colaborador.getSalario() + valorReajuste;
        colaborador.setSalario(novoSalario);
        totalSalariosReajustados++;
    }

    public void promoverColaborador(Colaborador colaborador, String novoCargo, double novoSalario) {
        if (novoSalario > colaborador.getSalario()) {
            colaborador.setCargo(novoCargo);
            colaborador.setSalario(novoSalario);
            totalPromovidos++;
        } else {
            System.out.println("Operação inválida: o novo salário é menor ou igual ao salário atual.");
        }
    }

    public int getTotalPromovidos() {
        return totalPromovidos;
    }

    public int getTotalSalariosReajustados() {
        return totalSalariosReajustados;
    }
}
