public class TreinadorPokemon {
    private String nome;
    private int nivel;

    public TreinadorPokemon(String nome) {
        this.nome = nome;
        this.nivel = 1; // Nível inicial é 1
    }

    public void treinarPokemon(Pokémon pokemon) {
        int forcaAtual = pokemon.getForca();
        int forcaAumentada = (int) (forcaAtual * 0.10); // Aumento de 10%
        pokemon.setForca(forcaAtual + forcaAumentada);

        int docesAtuais = pokemon.getDoces();
        pokemon.setDoces(docesAtuais + 10);

        nivel += 2;
    }

    public void evoluirPokemon(Pokémon pokemon, String nomeEvolucao) {
        int docesAtuais = pokemon.getDoces();
        if (docesAtuais >= 50) {
            pokemon.setNome(nomeEvolucao);
            pokemon.setDoces(docesAtuais - 50);
            nivel += 10;
            System.out.println("Pokémon " + pokemon.getNome() + " evoluiu para -> " + nomeEvolucao);
        } else {
            System.out.println("Não foi possível realizar a evolução.");
        }
    }

    public String getNome() {
        return nome;
    }

    public int getNivel() {
        return nivel;
    }
}
