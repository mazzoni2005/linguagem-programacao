public class TestePokemon {
    public static void main(String[] args) {
        Pokémon pokemon1 = new Pokémon("Pikachu", "Elétrico", 50);
        Pokémon pokemon2 = new Pokémon("Bulbasaur", "Grama/Veneno", 45);

        // Crie um treinador
        TreinadorPokemon treinador = new TreinadorPokemon("Ash");

        for (int i = 0; i < 5; i++) {
            treinador.treinarPokemon(pokemon1);
        }

        System.out.println("Pokémon 1 - Nome: " + pokemon1.getNome() + ", Tipo: " + pokemon1.getTipo() + ", Força: " + pokemon1.getForca() + ", Doces: " + pokemon1.getDoces());

        treinador.evoluirPokemon(pokemon1, "Raichu");

        System.out.println("Pokémon 1 - Nome: " + pokemon1.getNome() + ", Tipo: " + pokemon1.getTipo() + ", Força: " + pokemon1.getForca() + ", Doces: " + pokemon1.getDoces());

        Pokémon pokemon3 = new Pokémon("Charmander", "Fogo", 40);

        for (int i = 0; i < 2; i++) {
            treinador.treinarPokemon(pokemon3);
        }

        System.out.println("Pokémon 3 - Nome: " + pokemon3.getNome() + ", Tipo: " + pokemon3.getTipo() + ", Força: " + pokemon3.getForca() + ", Doces: " + pokemon3.getDoces());

        treinador.evoluirPokemon(pokemon3, "Charizard");

        System.out.println("Status do Treinador:");
        System.out.println("Nome: " + treinador.getNome());
        System.out.println("Nível: " + treinador.getNivel());
    }
}
