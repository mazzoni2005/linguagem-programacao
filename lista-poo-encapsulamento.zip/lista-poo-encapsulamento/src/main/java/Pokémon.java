public class Pokémon {
    private String nome;
    private String tipo;
    private int forca;
    private int doces;

    public Pokémon(String nome, String tipo, int forca) {
        this.nome = nome;
        this.tipo = tipo;
        this.forca = forca;
        this.doces = 0; // Valor padrão de doces é 0
    }

    public String getNome() {
        return nome;
    }

    public String getTipo() {
        return tipo;
    }

    public int getForca() {
        return forca;
    }

    public int getDoces() {
        return doces;
    }

    public void setDoces(int doces) {
        this.doces = doces;
    }

    public void setForca(int forca) {
        this.forca = forca;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
