public class TesteColaborador {
    public static void main(String[] args) {
            // Crie dois objetos do tipo Colaborador
            Colaborador colaborador1 = new Colaborador("Allan", "Analista", 5000.0);
            Colaborador colaborador2 = new Colaborador("Phill", "Gerente", 8000.0);

            // Crie um objeto do tipo RecursosHumanos
            RecursosHumanos recursosHumanos = new RecursosHumanos();

            // Exiba as informações dos colaboradores
            System.out.println("Informações dos Colaboradores:");
            System.out.println("Colaborador 1: " + colaborador1.getNome() + " - Cargo: " + colaborador1.getCargo() + " - Salário: " + colaborador1.getSalario());
            System.out.println("Colaborador 2: " + colaborador2.getNome() + " - Cargo: " + colaborador2.getCargo() + " - Salário: " + colaborador2.getSalario());

            // Promova um colaborador com salário maior
            recursosHumanos.promoverColaborador(colaborador1, "Senior Analista", 6000.0);

            // Promova um colaborador com salário menor (operação inválida)
            recursosHumanos.promoverColaborador(colaborador2, "Senior Gerente", 7500.0);

            // Faça o reajuste de salário de um colaborador
            recursosHumanos.reajustarSalario(colaborador2, 8500.0);

            // Exiba novamente as informações dos colaboradores
            System.out.println("\nInformações dos Colaboradores Após Promoção e Reajuste:");
            System.out.println("Colaborador 1: " + colaborador1.getNome() + " - Cargo: " + colaborador1.getCargo() + " - Salário: " + colaborador1.getSalario());
            System.out.println("Colaborador 2: " + colaborador2.getNome() + " - Cargo: " + colaborador2.getCargo() + " - Salário: " + colaborador2.getSalario());

            // Exiba o total de promovidos
            System.out.println("\nTotal de Colaboradores Promovidos: " + recursosHumanos.getTotalPromovidos());

            // Exiba o total de salários reajustados
            System.out.println("Total de Salários Reajustados: " + recursosHumanos.getTotalSalariosReajustados());
        }
}
